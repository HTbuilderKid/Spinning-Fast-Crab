import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color; 

public class GameOverWorld extends World
{
    private int wormsEaten;
    public GameOverWorld()
    {
        super(1000, 800, 1);
        showText("Game Over! Worms eaten: " + wormsEaten, getWidth() / 2, getHeight() / 2);
        Greenfoot.stop();
    }
}
