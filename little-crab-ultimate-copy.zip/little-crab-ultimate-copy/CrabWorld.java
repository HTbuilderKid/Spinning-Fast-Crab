import greenfoot.*;  

public class CrabWorld extends World
{
    private int spawnCounter = 0;      
    private int spawnInterval = 300;   
    private int maxLobsters = 5;   //only 5 lobsters cuz otherwise it's too hard
    private int boostTimer = 0;
    private boolean timeStopped = false;
    
    public void setTimeStopped(boolean value) 
    {
        timeStopped = value;
    }
    
    public boolean isTimeStopped() 
    {
        return timeStopped;
    }

    public CrabWorld() 
    {
        super(1000, 800, 1);
        prepare();
    }

    public void act()
    {
        spawnCounter++;
        boostTimer++;
        if (spawnCounter >= spawnInterval) {
            spawnCounter = 0;
            maybeSpawnLobster();
        }
        if (boostTimer >= 1200) {
            spawnRandomBoost();
            boostTimer = 0;
        }
    }

    private void maybeSpawnLobster()
    {
        int current = getObjects(Lobster.class).size();

        if (current < maxLobsters) {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = Greenfoot.getRandomNumber(getHeight());
            addObject(new Lobster(), x, y);
        }
    }

    private void prepare()
    {
        Crab crab = new Crab();
        addObject(crab, getWidth() / 2, getHeight() / 2);

        for (int i = 0; i < 10; i++) {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = Greenfoot.getRandomNumber(getHeight());
            addObject(new Worm(), x, y);
        }
    }
    
    private void spawnRandomBoost() {
    int roll = Greenfoot.getRandomNumber(100);

    if (roll < 50) { 
        addObject(new InvincibilityBoost(),
            Greenfoot.getRandomNumber(getWidth()),
            Greenfoot.getRandomNumber(getHeight()));
    } else if (roll < 75) {
        addObject(new FlashBoost(),
            Greenfoot.getRandomNumber(getWidth()),
            Greenfoot.getRandomNumber(getHeight()));
    }
    }
}