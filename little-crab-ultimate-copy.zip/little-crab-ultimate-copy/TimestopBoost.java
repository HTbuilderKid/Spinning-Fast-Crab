import greenfoot.*;

public class TimestopBoost extends PowerBoost {
    public TimestopBoost() {
        setImage("timestop.png"); 
    }

    @Override
    public void applyEffect(Crab crab) {
        crab.timeStop(300); 
    }
}
