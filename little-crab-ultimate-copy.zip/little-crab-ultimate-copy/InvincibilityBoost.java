import greenfoot.*;

public class InvincibilityBoost extends PowerBoost {
    public InvincibilityBoost() {
        setImage("shield.png"); 
    }

    @Override
    public void applyEffect(Crab crab) {
        crab.activateInvincibility(600); 
    }
}
