import greenfoot.*;

public class FlashBoost extends PowerBoost {
    public FlashBoost() {
        setImage("flash.png"); 
    }

    @Override
    public void applyEffect(Crab crab) {
        crab.flashAbility();
    }
}
