import greenfoot.*;

public class GiantLobster extends Actor {
    private int health = 5; 
    private int spawnCounter = 0; 
    private int spawnInterval = 180; 
    private int moveSpeed = 1;  

    public void act() {
        setLocation(getX() + moveSpeed, getY());
        if (getX() <= 50 || getX() >= getWorld().getWidth() - 50) {
            moveSpeed = -moveSpeed; 
        }

        spawnCounter++;
        if (spawnCounter >= spawnInterval) {
            spawnCounter = 0;
            spawnMinion();
        }

        if (getWorld() instanceof BossWorld) {
            ((BossWorld)getWorld()).updateBossHealthBar();
        }

        if (health <= 0) {
            Greenfoot.playSound("bossDefeated.wav"); 
            getWorld().removeObject(this);
            Greenfoot.setWorld(new GameWonWorld()); 
        }
    }

    private void spawnMinion() {
        World world = getWorld();
        if (world != null) {
            int x = Greenfoot.getRandomNumber(world.getWidth());
            int y = Greenfoot.getRandomNumber(world.getHeight() / 2) + world.getHeight() / 2;
            world.addObject(new LobsterMinion(this), x, y);
        }
    }

    public void takeDamage(int amount) {
        health -= amount;
    }

    public int getHealth() { return health; }
    public int getMaxHealth() { return 20; }
}
