import greenfoot.*;

public abstract class PowerBoost extends Actor {
    public abstract void applyEffect(Crab crab); //this uses the same logic as the mover from the Asteroids game.
}