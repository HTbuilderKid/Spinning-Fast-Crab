import greenfoot.*;  // (World, Actor, Greenfoot, GreenfootImage)

public class GameWonWorld extends World
{
    private int timer = 0;
    private int wormsEaten;
    private final int showDuration = 400; 

    public GameWonWorld()
    {
        super(1000, 800, 1);

        showText("Yoooo! You won the game!!! Worms eaten: " + wormsEaten, getWidth() / 2, getHeight() / 2);
        showText("Get ready for the boss...", getWidth() / 2, getHeight() / 2 + 40);
    }

    public void act()
    {
        timer++;

        if (timer == 1) {
            Greenfoot.playSound("gameWon.wav");
        }

        if (timer >= showDuration) {
            Greenfoot.setWorld(new BossWorld());
        }
    }
}