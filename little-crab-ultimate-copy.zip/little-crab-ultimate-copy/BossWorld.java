import greenfoot.*;

public class BossWorld extends World {
    private GiantLobster boss;

    public BossWorld() {
        super(1000, 800, 1);
        prepare();
    }

    private void prepare() {
        Greenfoot.playSound("bossMusic.wav");
        Crab crab = new Crab();
        addObject(crab, getWidth() / 2, getHeight() - 100);

        boss = new GiantLobster();
        addObject(boss, getWidth() / 2, 150);

        showText("Giant Lobster", getWidth() / 2, 30);
        updateBossHealthBar();
    }

    public void updateBossHealthBar() {
        if (boss != null) {
            int hp = boss.getHealth();
            int maxHp = boss.getMaxHealth();
            showText("HP: " + hp + "/" + maxHp, getWidth() / 2, 60);
        }
    }
}
