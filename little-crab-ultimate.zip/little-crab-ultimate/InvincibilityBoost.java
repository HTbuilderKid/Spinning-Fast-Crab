import greenfoot.*;

public class InvincibilityBoost extends PowerBoost {
    public InvincibilityBoost() {
        setImage("herz.png"); // placeholder, add your image
    }

    @Override
    public void applyEffect(Crab crab) {
        crab.activateInvincibility(600); // 600 frames = 10 seconds
    }
}
