import greenfoot.*;

public class FlashBoost extends PowerBoost {
    public FlashBoost() {
        setImage("herz.png"); // placeholder
    }

    @Override
    public void applyEffect(Crab crab) {
        crab.flashAbility();
    }
}
