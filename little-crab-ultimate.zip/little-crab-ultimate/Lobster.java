import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * A lobster that eats crabs. Bad lobster!!
 */
public class Lobster extends Actor
{
    private int normalSpeed = 5;
    private int slowSpeed = 2;
    private int currentSpeed = normalSpeed;
    private int flashTimer = 0;

    public void act()
    {
        turnAtEdge();
        randomTurn();
        move(currentSpeed);
        lookForCrab();
        checkBullet();
        updateFlash();
    }

    public void turnAtEdge()
    {
        if (isAtEdge()) 
        {
            turn(17);
        }
    }

    public void randomTurn()
    {
        if (Greenfoot.getRandomNumber(100) > 90) 
        {
            turn(Greenfoot.getRandomNumber(90)-45);
        }
    }

    public void lookForCrab()
    {
        Crab crab = (Crab) getOneIntersectingObject(Crab.class);
        if (crab != null) 
        {
            // Check if crab is invincible
            if (!crab.isInvincible()) 
            {
                removeTouching(Crab.class);
                Greenfoot.playSound("gameOver.wav");
                Greenfoot.setWorld(new GameOverWorld());
            }
            // else: crab is invincible, do nothing
        }
    }
    
    private void checkBullet() 
    {
        Bullet a = (Bullet) getOneIntersectingObject(Bullet.class);
        if (a != null) {
            Greenfoot.playSound("au.wav");
            getWorld().removeObject(a);

            // slow down the lobster because it got hit
            currentSpeed = slowSpeed;
            flashTimer = 300; 
        }
    }

    private void updateFlash()
    {
        if (flashTimer > 0) {
            flashTimer--;

            // toggle visibility for flashing effect
            if (flashTimer % 10 < 5) {
                getImage().setTransparency(100); // semi-transparent
            } else {
                getImage().setTransparency(255); // normal
            }

            // when timer ends, reset
            if (flashTimer == 0) {
                currentSpeed = normalSpeed;
                getImage().setTransparency(255);
            }
        }
    }
}