import greenfoot.*;  

public class CrabWorld extends World
{
    private int spawnCounter = 0;       // timer for lobster spawns
    private int spawnInterval = 300;    // frames between spawns (~5 seconds at 60 fps)
    private int maxLobsters = 5;        // maximum lobsters allowed
    private int boostTimer = 0;
    private boolean timeStopped = false;
    
    public void setTimeStopped(boolean value) 
    {
        timeStopped = value;
    }
    
    public boolean isTimeStopped() 
    {
        return timeStopped;
    }

    public CrabWorld() 
    {
        super(1000, 800, 1);
        prepare();
    }

    public void act()
    {
        spawnCounter++;
        boostTimer++;
        // Time to spawn?
        if (spawnCounter >= spawnInterval) {
            spawnCounter = 0;  // reset timer
            maybeSpawnLobster();
        }
        if (boostTimer >= 1200) {
            spawnRandomBoost();
            boostTimer = 0;
        }
    }

    private void maybeSpawnLobster()
    {
        // Count how many lobsters are currently in the world
        int current = getObjects(Lobster.class).size();

        if (current < maxLobsters) {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = Greenfoot.getRandomNumber(getHeight());
            addObject(new Lobster(), x, y);
        }
    }

    private void prepare()
    {
        // add a crab at the start
        Crab crab = new Crab();
        addObject(crab, getWidth() / 2, getHeight() / 2);

        // add some worms at random
        for (int i = 0; i < 10; i++) {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = Greenfoot.getRandomNumber(getHeight());
            addObject(new Worm(), x, y);
        }
    }
    
    private void spawnRandomBoost() {
    int roll = Greenfoot.getRandomNumber(100);

    if (roll < 50) { // 50% chance for Invincibility
        addObject(new InvincibilityBoost(),
            Greenfoot.getRandomNumber(getWidth()),
            Greenfoot.getRandomNumber(getHeight()));
    } else if (roll < 75) { // 25% chance for Flash
        addObject(new FlashBoost(),
            Greenfoot.getRandomNumber(getWidth()),
            Greenfoot.getRandomNumber(getHeight()));
    }
    }
}