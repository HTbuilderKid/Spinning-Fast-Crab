import greenfoot.*;

public abstract class PowerBoost extends Actor {
    // Every boost must implement this
    public abstract void applyEffect(Crab crab);
}