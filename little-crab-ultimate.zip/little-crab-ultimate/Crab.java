import greenfoot.*;  

public class Crab extends Actor
{
    private int gunReloadTime;
    private int reloadDelayCount;
    private int shotsFired;
    private GreenfootImage image1;
    private GreenfootImage image2;
    private int wormsEaten;
    private int baseSpeed;
    private int currentSpeed;
    private int boostTimer; 
    private int animationCounter;
    private boolean isInvincible = false;
    private int invincibleTimer = 0;
    private boolean isTimeStopped = false;
    private int timeStopTimer = 0;
    private int flashTimer = 0;

    public Crab()
    {
        image1 = new GreenfootImage("crab.png");
        image2 = new GreenfootImage("crab2.png");
        setImage(image1);

        gunReloadTime = 35;
        reloadDelayCount = 0;
        shotsFired = 0;
        wormsEaten = 0;
        flashTimer = 0;

        baseSpeed = 2;
        currentSpeed = baseSpeed;
        boostTimer = 0;

        animationCounter = 0;

        displayCount();
    }

    public void act()
    {
        boolean moved = moveAround(); 
        checkKeys();
        reloadDelayCount++;
        lookForWorm();
        checkBoostPickup();
        updateBoosts();

        if (moved) {
            animationCounter++;
            if (animationCounter % 10 == 0) { 
                switchImage();
            }
        } else {
            setImage(image1); 
        }

        if (flashTimer > 0) {
            flashTimer--;
            if (flashTimer % 5 == 0) {
                if (getImage() == image1) setImage(image2);
                else setImage(image1);
            }
        }

        if (boostTimer > 0) {
            boostTimer--;
            if (boostTimer == 0) {
                currentSpeed = baseSpeed;
            }
        }
    }
    
    private void checkBoostPickup() 
    {
        PowerBoost boost = (PowerBoost) getOneIntersectingObject(PowerBoost.class);
        if (boost != null) {
        boost.applyEffect(this);
        getWorld().removeObject(boost);
    }
    }

    private boolean moveAround() {
        int dx = 0;
        int dy = 0;

        if (Greenfoot.isKeyDown("up")) dy -= currentSpeed;
        if (Greenfoot.isKeyDown("down")) dy += currentSpeed;
        if (Greenfoot.isKeyDown("left")) dx -= currentSpeed;
        if (Greenfoot.isKeyDown("right")) dx += currentSpeed;

        if (dx != 0 || dy != 0) {
            setLocation(getX() + dx, getY() + dy);
            return true; 
        }
        return false;
    }

    private void switchImage()
    {
        if (getImage() == image1) {
            setImage(image2);
        } else {
            setImage(image1);
        }
    }

    private void checkKeys() 
    {
        if(Greenfoot.isKeyDown("space")) {
            Greenfoot.playSound("EnergyGun.wav");
            fire();
        }        
    }

    private void fire() 
    {
        if (reloadDelayCount >= gunReloadTime) {
            Bullet b = new Bullet(getRotation());
            getWorld().addObject(b, getX(), getY());
            shotsFired++;
            reloadDelayCount = 0;
        }
    }

    public void lookForWorm()
    {
        if (isTouching(Worm.class))
        {
            removeTouching(Worm.class);

            if (Greenfoot.getRandomNumber(2) == 0)
                Greenfoot.playSound("slurp.wav");
            else
                Greenfoot.playSound("gulp.wav");

            wormsEaten++;
            flashTimer = 40; 
            currentSpeed = baseSpeed + 1; // add a speed boost cuz we that good
            boostTimer = 300; // lasts ~5 seconds

            if (wormsEaten % 5 == 0 && gunReloadTime > 10) {
                gunReloadTime -= 5; // faster shooting every 5 worms
            }

            displayCount();

            // inside Crab.lookForWorm()
            if (wormsEaten == 10)
            {
            Greenfoot.playSound("gameWon.wav");
            Greenfoot.setWorld(new GameWonWorld());
            }
        }
    }

    private void displayCount()
    {
        World world = getWorld();
        if (world != null) {
            world.showText("Worms eaten: " + wormsEaten, 80, 20);
        }
    }

    public int getWormsEaten() {
        return wormsEaten;
    }
    
    public void activateInvincibility(int duration) {
    isInvincible = true;
    invincibleTimer = duration;
    }
    
    public void flashAbility() {
    flashTimer = 500; // 3 seconds
    }
    
    public void timeStop(int duration) {
    isTimeStopped = true;
    timeStopTimer = duration;
    CrabWorld world = (CrabWorld) getWorld();
    world.setTimeStopped(true);
    }
    
    public boolean isInvincible() {
    return isInvincible;
    }
    
    private void updateBoosts() 
    {
        if (isInvincible) {
        invincibleTimer--;
        if (invincibleTimer % 20 < 10) getImage().setTransparency(150);
        else getImage().setTransparency(255);

        if (invincibleTimer <= 0) {
            isInvincible = false;
            getImage().setTransparency(255);
        }
    }
    
    if (flashTimer > 0) {
        flashTimer--;
    }

    if (isTimeStopped) {
        timeStopTimer--;
        if (timeStopTimer <= 0) {
            isTimeStopped = false;
            CrabWorld world = (CrabWorld) getWorld();
            world.setTimeStopped(false);
        }
    }
    }
}