import greenfoot.*;

public class BossWorld extends World {
    private GiantLobster boss;

    public BossWorld() {
        super(1000, 800, 1);
        prepare();
    }

    private void prepare() {
        // Add player
        Crab crab = new Crab();
        addObject(crab, getWidth() / 2, getHeight() - 100);

        // Add boss
        boss = new GiantLobster();
        addObject(boss, getWidth() / 2, 150);

        // Add boss name + HP bar UI
        showText("Giant Lobster", getWidth() / 2, 30);
        updateBossHealthBar();
    }

    public void updateBossHealthBar() {
        if (boss != null) {
            int hp = boss.getHealth();
            int maxHp = boss.getMaxHealth();
            showText("HP: " + hp + "/" + maxHp, getWidth() / 2, 60);
        }
    }
}
