import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color; 

public class GameWonWorld extends World
{
    public GameWonWorld()
    {
        super(600, 400, 1);
        showText("Yoooo! You won the game!!!", getWidth() / 2, getHeight() / 2);
        Greenfoot.stop();
    }
}