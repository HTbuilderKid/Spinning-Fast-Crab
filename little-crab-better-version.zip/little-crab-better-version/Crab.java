import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * A rocket that can be controlled by the arrowkeys: up, left, right.
 * The gun is fired by hitting the 'space' key.
 * 
 * @author Poul Henriksen
 * @author Michael Kölling
 * 
 * @version 2.0
 */
public class Crab extends Mover
{
    private int gunReloadTime;              // The minimum delay between firing the gun.
    private int reloadDelayCount;           // How long ago we fired the gun the last time.
    private Vector acceleration;            // A vector used to accelerate when using booster.
    private int shotsFired;                 // Number of shots fired.
    private GreenfootSound mySound;
    private GreenfootImage rocket = new GreenfootImage("crab.png");
    private boolean soundPlayed = false;
    private GreenfootImage image1;
    private GreenfootImage image2;
    private int wormsEaten;
    

    /**
     * Initialise this rocket.
     */
    public Crab()
    {
        image1 = new GreenfootImage("crab.png");
        image2 = new GreenfootImage("crab2.png");
        setImage(image1);
        gunReloadTime = 35;
        reloadDelayCount = 0;
        acceleration = new Vector(0, 0.3);    // used to accelerate when thrust is on
        increaseSpeed(new Vector(13, 0.3));   // initially slowly drifting
        shotsFired = 0;
        wormsEaten = 0;
        displayCount();
    }

    /**
     * Do what a rocket's gotta do. (Which is: mostly flying about, and turning,
     * accelerating and shooting when the right keys are pressed.)
     */
    public void act()
    {
        move();
        checkKeys();
        reloadDelayCount++;
        //wormsEaten;
        lookForWorm();
        switchImage();
    }
    
    /**
     * Return the number of shots fired from this rocket.
     */
    public int getShotsFired()
    {
        return shotsFired;
    }
    
    public void switchImage()
    {
        if (getImage() == image1)
        {
            setImage(image2);
        }
        else
        {
            setImage(image1);
        }
    }
    
    private void ignite(boolean boosterOn) {
    if (boosterOn) {
        acceleration.setDirection(getRotation());
        increaseSpeed(acceleration);
        if (!soundPlayed) {
            Greenfoot.playSound("gas.wav");
            soundPlayed = true;
        }
    } else {
        setImage(rocket);
        soundPlayed = false;
    }
    }
    
    /**
     * Set the time needed for re-loading the rocket's gun. The shorter this time is,
     * the faster the rocket can fire. The (initial) standard time is 20.
     */
    public void setGunReloadTime(int reloadTime)
    {
        gunReloadTime = reloadTime;
    }
    
    /**
     * Check whether there are any key pressed and react to them.
     */
    private void checkKeys() 
    {
        ignite(Greenfoot.isKeyDown("up"));
        
        if(Greenfoot.isKeyDown("left")) {
            turn(-5);
        }        
        if(Greenfoot.isKeyDown("right")) {
            turn(5);
        }
        if(Greenfoot.isKeyDown("space")) {
            fire();
        }        
    }

    /**
     * Fire a bullet if the gun is ready.
     */
    private void fire() 
    {
        if (reloadDelayCount >= gunReloadTime) {
            Bullet b = new Bullet(getMovement().copy(), getRotation());
            getWorld().addObject(b, getX(), getY());
            b.move();
            shotsFired++;
            reloadDelayCount = 0;   // time since last shot fired
        }
    }
    
    public void lookForWorm()
    {
        if (isTouching(Worm.class))
        {
            removeTouching(Worm.class);
            Greenfoot.playSound("slurp.wav");
            wormsEaten = wormsEaten + 1;
            //wormsEaten++;
            
            if (wormsEaten  == 10)
            {
                Greenfoot.playSound("gameWon.wav");
                Greenfoot.setWorld(new GameWonWorld());
            }
        }
    }
    
    private void displayCount()
    {
        System.out.println("Worms eaten: " + wormsEaten);
    }
    
    public int getWormsEaten() {
        return wormsEaten;
    }
}